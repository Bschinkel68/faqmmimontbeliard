<?php
/**
 * LifterLMS custom wrapper (end).
 *
 * @package Page Builder Framework
 * @subpackage Integration/LifterLMS
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

?>

</main>

<?php do_action( 'wpbf_sidebar_right' ); ?>

</div>

<?php do_action( 'wpbf_inner_content_close' ); ?>

<?php wpbf_inner_content_close(); ?>

<?php do_action( 'wpbf_content_close' ); ?>
	
</div>
