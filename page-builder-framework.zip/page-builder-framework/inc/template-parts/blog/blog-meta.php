<?php
/**
 * Meta.
 *
 * Renders author/post meta on archives.
 *
 * @package Page Builder Framework
 * @subpackage Template Parts
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

wpbf_article_meta();
