<?php
/**
 * Title.
 *
 * Renders the title on posts.
 *
 * @package Page Builder Framework
 * @subpackage Template Parts
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

wpbf_title();
